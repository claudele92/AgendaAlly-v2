# AgendaAlly scheduling implementation

Implemented the selected task-focused booking and scheduling direction as an
incremental presentation extraction. Role services, providers, event selection,
permissions, API contracts, persisted Redux state, and business rules remain
role-owned. No database, backend, runtime, environment, or evidence changes.

## Changed inventory units

- **Customer booking date and backend slot selection** — enhanced the existing
  slot controls with explicit selection semantics and a selected appointment
  summary. Only the existing backend-returned slots are selectable.
- **Customer discovery date/time pair** — kept the date-picker engine and wire
  values; added clearer accessible navigation and a keyboard-visible time
  control.
- Existing checkout/confirmation, booking history/detail, cancellation, and
  rescheduling actions were retained in their current Customer paths; this
  change does not replace their contract or duplicate those flows.
- **Admin, Vendor, Specialist calendars** — the three calendar components now
  use one Business-side `ScheduleSurface` for date navigation, Today, day/week/
  agenda selection, event list presentation, loading/error/empty states, and a
  narrow-screen agenda. Their distinct event selection, detail loading,
  disabled-time loading, booking calculation, and role services remain intact.
- **Three weekly-hours/closed-date editors** — retained each role's separate
  owner, service calls, and form state; applied the shared scheduling-field
  presentation class to the existing working-hours/closed-dates layout.
- **Six blocked-time editors** — retained their separate role-specific fields,
  validation, repeat behavior, and submit paths; applied shared scheduling
  field styling to their existing form grids.
- **Three recurrence editors** — retained the original recurrence form fields
  and values; composed them using `SchedulingFieldSection` in all three trees.

The Admin booking list/search/filter/detail/status oversight workflow is
intentionally retained as primary and unchanged; the calendar remains optional.
Drawer width was bounded on the Admin calendar path; Vendor and Specialist
drawers already had a viewport-aware width.

## Files changed

- `.migration-backup/admin/src/components/scheduling/ScheduleSurface.jsx`
- `.migration-backup/admin/src/components/scheduling/SchedulingFieldSection.jsx`
- `.migration-backup/admin/src/components/scheduling/schedule-surface.css`
- `.migration-backup/admin/src/views/calendar/components/calendar.jsx`
- `.migration-backup/admin/src/views/seller-views/calendar/components/calendar.jsx`
- `.migration-backup/admin/src/views/master-views/calendar/components/calendar.jsx`
- `.migration-backup/admin/src/views/calendar/components/drawer-view.jsx`
- `.migration-backup/admin/src/views/calendar/forms/repeat-form-option.jsx`
- `.migration-backup/admin/src/views/seller-views/calendar/forms/repeat-form-option.jsx`
- `.migration-backup/admin/src/views/master-views/calendar/forms/repeat-form-option.jsx`
- `.migration-backup/admin/src/views/calendar/forms/blocktime-form.jsx`
- `.migration-backup/admin/src/views/seller-views/calendar/forms/blocktime-form.jsx`
- `.migration-backup/admin/src/views/master-views/calendar/forms/blocktime-form.jsx`
- `.migration-backup/admin/src/views/user/disabled-times/form.jsx`
- `.migration-backup/admin/src/views/seller-views/master-invitations/disabled-times/form.jsx`
- `.migration-backup/admin/src/views/master-views/disabled-times/disabled-time-form.jsx`
- `.migration-backup/admin/src/views/user/master-working-and-closed-days.jsx`
- `.migration-backup/admin/src/views/seller-views/master-invitations/working-and-closed-days.jsx`
- `.migration-backup/admin/src/views/master-views/closed-days/closed-days.jsx`
- `.migration-backup/web/app/(store)/(booking)/(witout-footer)/(navigation)/shops/[id]/components/date-time/date-time.tsx`
- `.migration-backup/web/components/search-field-core/date-select.tsx`
- `.migration-backup/web/components/search-field-core/time-select.tsx`

## Assumptions and remaining gaps

- Existing Redux calendar events provide start/end dates and, depending on the
  role mapper, status. The new view does not invent payment or collection
  evidence; existing appointment detail remains the source for those fields.
- The Admin event mapper does not include appointment status in its calendar
  event projection. The presentation labels those rows as appointments rather
  than asserting a status. The existing Admin booking list/detail remains the
  status and financial oversight surface.
- On mobile, the calendar grid is replaced by a date-scoped agenda while
  keeping existing event-selection and selectable-time callbacks. The existing
  role adapters remain responsible for enforcing authorized actions.
- Tablet layout and signed-in browser rendering were not separately verified.
  No full certification/build or browser campaign was run; the main agent owns
  the focused B1/U1 browser campaign.

## Checks run

- Babel JSX/TypeScript parser accepted all changed JavaScript/JSX/TSX modules.
- `git diff --check` passed.
- Existing targeted calendar regression tests passed: 3/3.

No readiness score, staging certification, or production approval is asserted.