# Email-system audit evidence — 2026-10-05

The canonical current report is `docs/development/agendaally-email-system-audit.html`.
It is self-contained, has exactly the requested 30 sections, embeds the full
17-field inventory, and contains the required separate evidence levels.
`agendaally-email-inventory.csv` is the same inventory in spreadsheet form.

This audit sent zero messages and made zero SMTP connections. Rendering used an
in-memory database, synthetic `.invalid` addresses, actual Blade and local MIME
assembly with transport/network/process functions disabled. No application
sender method, send or postSend was invoked. Driver MIME is local Symfony
construction, not Laravel transport proof.

The final new-suite JUnit receipt is `email-system-audit-junit.xml`: 5 tests,
198 assertions, no failures. One existing PHPUnit configuration deprecation
remains. The initial fixture-failure JUnit is retained transparently: the
synthetic order graph supplied a null logo unlike the native sender; the fixture
was corrected, not application code.

The seven fixture HTML/EML/JSON triples and contact sheets are local synthetic
presentation/MIME evidence. Browser image sources are exact attached bytes
substituted as data URIs. They are not Gmail emulation. Individual narrow
captures retain footer/overflow evidence beyond the contact-sheet iframe height.
`responsive-observations.json` transcribes screenshot-console DOM measurements.

`smtp-owner-delivery-current.json` records owner-confirmed normal Admin SMTP,
Gmail receipt and corrected logo/social/footer presentation. The prior receipt
is explicitly historical, not current authority.

`preservation.json` records no changes in 206 table fingerprints, 467 schema
objects or 4,683 protected application-source files. The SMTP password was not
selected or independently hashed; no credential-write operation occurred.
Before/after database snapshots contain counts/hashes only, not business rows.
The source snapshot contains paths/hashes, not source or credential values.

Prior A1 and N1 acceptance is reused in the report; no broad campaign, selected
worker, scheduler or acceptance workflow was launched during this audit.
Current C1/O4 remain 0.5 and the score remains 16/20 = 80%, REMAIN IN STAGING.
Two future real account messages are proposed but not authorized/executed.

Only audit tests, docs, synthetic previews and evidence were added/updated.
Implementation, schema changes, template/workflow activation and real-mail
testing await explicit approval.
