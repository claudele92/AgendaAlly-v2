# Retired disposable engine proof evidence

See comparison-report.md and adaptations.md.

Both native engine proofs stopped at the same new confirmation-replay failure.
No application remediation is present. Wallet/fulfillment and later gates are
explicitly not run. The original thirteen MySQL financial cases passed unchanged.

The retired-harness-source.tar.gz is a quarantined historical reproduction record,
NOT active application code, a migration or approved executable follow-up.
Temporary PostgreSQL DDL overlays are documented as inert diffs. Do not extract,
provision, rerun or implement them without new explicit authorization.

Engine-specific expanded JSON records distinguish passed/failed/not-run groups.
Each worker input/result records exact synthetic bindings, SQL and native error/
transaction outcomes. The failure is a DomainException, not an invented SQLSTATE.
Native deadlock/timeout events are recorded separately. Setup interruptions are
retained and are not counted as new application financial invariant failures.

protected-comparison.json verifies the exact original 59-table/465-object baseline,
four empty completion tables and 12 unverified Orders.
source-preservation.json records 1761 unchanged native source hashes.
No production or real provider/customer financial data was used.